/* =====================================================================
   CONFIG — this is the ONLY block you need to edit to make the site
   yours. Everything else (buttons, links, footer) reads from here.
   ===================================================================== */
const CONFIG = {
  // Full phone number with country code, digits only (no +, no spaces).
  // Example for India: "919876543210"
  phone: "919999999999",

  // How the number is displayed on buttons (can include + and spaces)
  phoneDisplay: "+91 99999 99999",

  // Pre-filled message that opens when someone taps the WhatsApp button
  whatsappMessage: "Hi! I found your website and I'm looking for a shifting quote.",

  // Get this from https://web3forms.com — sign up with the Gmail address
  // where you want quote/review submissions delivered. Paste the key below.
  web3formsAccessKey: "YOUR_WEB3FORMS_ACCESS_KEY_HERE",
};

/* =====================================================================
   Bind CONFIG values to the page (buttons, phone links, WhatsApp links)
   ===================================================================== */
function buildTelHref() {
  return `tel:+${CONFIG.phone}`;
}
function buildWhatsappHref() {
  const cleanPhone = CONFIG.phone.replace(/[^0-9]/g, "");
  return `https://wa.me/${cleanPhone}?text=${encodeURIComponent(CONFIG.whatsappMessage)}`;
}

function bindConfigToPage() {
  document.querySelectorAll('[data-bind="phoneDisplay"]').forEach((el) => {
    el.textContent = CONFIG.phoneDisplay;
  });
  document.querySelectorAll('[data-bind-href="tel"]').forEach((el) => {
    el.setAttribute("href", buildTelHref());
  });
  document.querySelectorAll('[data-bind-href="whatsapp"]').forEach((el) => {
    el.setAttribute("href", buildWhatsappHref());
    el.setAttribute("target", "_blank");
    el.setAttribute("rel", "noopener noreferrer");
  });
}

/* =====================================================================
   Mobile nav toggle
   ===================================================================== */
function setupMobileNav() {
  const btn = document.getElementById("hamburger");
  const nav = document.getElementById("main-nav");
  if (!btn || !nav) return;

  btn.addEventListener("click", () => {
    const isOpen = nav.classList.toggle("open");
    btn.setAttribute("aria-expanded", String(isOpen));
  });

  nav.querySelectorAll("a").forEach((link) => {
    link.addEventListener("click", () => {
      nav.classList.remove("open");
      btn.setAttribute("aria-expanded", "false");
    });
  });
}

/* =====================================================================
   Web3Forms submission helper
   Docs: https://docs.web3forms.com
   ===================================================================== */
async function submitToWeb3Forms(formEl, extraFields, resultEl, successMessage) {
  if (CONFIG.web3formsAccessKey === "YOUR_WEB3FORMS_ACCESS_KEY_HERE") {
    resultEl.textContent =
      "Setup needed: add your Web3Forms access key in js/script.js before this form can send emails.";
    resultEl.className = "form-note error";
    return;
  }

  const formData = new FormData(formEl);
  const payload = Object.fromEntries(formData);
  Object.assign(payload, extraFields, { access_key: CONFIG.web3formsAccessKey });

  resultEl.textContent = "Sending...";
  resultEl.className = "form-note";

  try {
    const response = await fetch("https://api.web3forms.com/submit", {
      method: "POST",
      headers: { "Content-Type": "application/json", Accept: "application/json" },
      body: JSON.stringify(payload),
    });
    const data = await response.json();

    if (data.success) {
      resultEl.textContent = successMessage;
      resultEl.className = "form-note success";
      formEl.reset();
    } else {
      resultEl.textContent = data.message || "Something went wrong. Please try again or WhatsApp us directly.";
      resultEl.className = "form-note error";
    }
  } catch (err) {
    resultEl.textContent = "Network error. Please try again or WhatsApp us directly.";
    resultEl.className = "form-note error";
  }
}

function setupQuoteForm() {
  const form = document.getElementById("quote-form");
  const result = document.getElementById("quote-result");
  if (!form) return;

  form.addEventListener("submit", (e) => {
    e.preventDefault();
    // Honeypot: if this hidden field got filled, it's very likely a bot.
    if (form.botcheck && form.botcheck.checked) return;

    submitToWeb3Forms(
      form,
      { subject: `New Quote Request — ${form.name.value}` },
      result,
      "Thank you! Your request has been sent. We'll contact you shortly."
    );
  });
}

function setupReviewForm() {
  const form = document.getElementById("review-form");
  const result = document.getElementById("review-result");
  if (!form) return;

  form.addEventListener("submit", (e) => {
    e.preventDefault();
    if (form.botcheck && form.botcheck.checked) return;

    submitToWeb3Forms(
      form,
      { subject: `New Review Submitted — ${form.name.value}` },
      result,
      "Thanks for your feedback! We'll review and publish it soon."
    );
  });
}

/* =====================================================================
   Reviews list — edit SEED_REVIEWS with your own real reviews any time.
   New submissions from the form above are emailed to you (not auto
   published) so you can vet them before adding them here.
   ===================================================================== */
const SEED_REVIEWS = [
  { name: "Sonal Kapoor", area: "Andheri East", rating: 5, text: "Very smooth shifting experience — every box was labeled and nothing was damaged." },
  { name: "Imran Sheikh", area: "Malad West", rating: 5, text: "Clear pricing with no last-minute surprises. The team was punctual and polite." },
  { name: "Divya Rao", area: "Bandra West", rating: 5, text: "Moved my 2 BHK in a single day. Careful with glass items and furniture." },
  { name: "Karan Mehta", area: "Borivali", rating: 4, text: "Good communication throughout. Would recommend for office relocations too." },
  { name: "Priyanka Joshi", area: "Powai", rating: 5, text: "Bike transport was handled really well — arrived without a scratch." },
  { name: "Arjun Nair", area: "Thane West", rating: 5, text: "Professional crew, arrived on time and finished loading faster than expected." },
  { name: "Meera Iyer", area: "Chembur", rating: 5, text: "They even helped arrange furniture in the new place. Great end-to-end service." },
  { name: "Rohit Deshpande", area: "Vashi", rating: 4, text: "Reliable and affordable. Kept us updated during transit." },
  { name: "Anjali Bhatt", area: "Goregaon", rating: 5, text: "Stress-free move from start to finish. Highly recommend to anyone relocating." },
];

let reviewsShown = 3;

function renderReviews() {
  const grid = document.getElementById("reviews-grid");
  if (!grid) return;
  grid.innerHTML = "";

  SEED_REVIEWS.slice(0, reviewsShown).forEach((r) => {
    const card = document.createElement("article");
    card.className = "card review-card";
    card.innerHTML = `
      <span class="stars">${"★".repeat(r.rating)}${"☆".repeat(5 - r.rating)}</span>
      <h4>${escapeHtml(r.name)}</h4>
      <span class="area">${escapeHtml(r.area || "")}</span>
      <p>${escapeHtml(r.text)}</p>
    `;
    grid.appendChild(card);
  });

  const loadMoreBtn = document.getElementById("load-more-reviews");
  if (loadMoreBtn) {
    loadMoreBtn.style.display = reviewsShown >= SEED_REVIEWS.length ? "none" : "inline-flex";
  }
}

function escapeHtml(str) {
  const div = document.createElement("div");
  div.textContent = str;
  return div.innerHTML;
}

function setupLoadMore() {
  const btn = document.getElementById("load-more-reviews");
  if (!btn) return;
  btn.addEventListener("click", () => {
    reviewsShown += 3;
    renderReviews();
  });
}

/* =====================================================================
   Init
   ===================================================================== */
document.addEventListener("DOMContentLoaded", () => {
  bindConfigToPage();
  setupMobileNav();
  setupQuoteForm();
  setupReviewForm();
  renderReviews();
  setupLoadMore();

  const yearEl = document.getElementById("year");
  if (yearEl) yearEl.textContent = new Date().getFullYear();
});
