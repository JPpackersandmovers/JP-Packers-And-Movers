# Your Packers & Movers Website

A ready-to-launch website: quote form that emails straight to your Gmail,
floating Call + WhatsApp buttons, services, process, gallery, and reviews.
No backend/server needed — it runs entirely as static files on GitHub Pages.

## Files
```
index.html        → the whole page
css/style.css      → all styling
js/script.js       → CONFIG block + form logic (edit this first!)
images/favicon.svg → browser tab icon
```

---

## Step 1 — Get your free Web3Forms access key (sends form data to Gmail)

Web3Forms is a free service that emails you whenever someone submits a form
on your site — no server required.

1. Go to **https://web3forms.com**
2. Enter the Gmail address where you want quotes/reviews to arrive → click
   **Create Access Key**
3. Web3Forms emails you an access key (a long code). Copy it.
4. Check your inbox (and Spam/Promotions tab) to confirm your email —
   otherwise submissions won't be delivered.

## Step 2 — Edit the CONFIG block

Open `js/script.js` in any text editor. At the very top you'll see:

```js
const CONFIG = {
  phone: "919999999999",              // your number, country code + digits, no + or spaces
  phoneDisplay: "+91 99999 99999",    // how it looks on buttons
  whatsappMessage: "Hi! I found your website...",
  web3formsAccessKey: "YOUR_WEB3FORMS_ACCESS_KEY_HERE",
};
```

Replace all four values with your own. This one block controls:
- the **Call Now** buttons and floating call icon (`tel:` link)
- the **WhatsApp** buttons and floating WhatsApp icon (opens a chat with
  your number and pre-filled message)
- where form submissions get emailed

## Step 3 — Replace the text placeholders

Open `index.html` and use **Find & Replace All** in your editor for:

| Find this exact text     | Replace with                          |
|---------------------------|----------------------------------------|
| `[COMPANY NAME]`           | Your business name                     |
| `[YOUR CITY]`               | The city/area you serve                |
| `[YOUR FULL ADDRESS]`       | Your office/shop address               |
| `[+91XXXXXXXXXX]`           | Your phone number (for search engines) |

Optional but recommended: replace the sample reviews inside `SEED_REVIEWS`
near the bottom of `js/script.js` with a few of your real reviews.

---

## Step 4 — Put it on GitHub Pages (free hosting)

1. Create a free GitHub account at **github.com** if you don't have one.
2. Click **New repository** → name it anything (e.g. `my-movers-website`) →
   set it to **Public** → Create.
3. Click **Add file → Upload files**, then drag in every file/folder from
   this project (`index.html`, `css/`, `js/`, `images/`) → **Commit changes**.
4. Go to the repo's **Settings → Pages**.
5. Under "Build and deployment", set **Source: Deploy from a branch**,
   **Branch: main**, folder **/(root)** → **Save**.
6. Wait 1–2 minutes, then refresh the page — GitHub will show your live
   link, e.g. `https://yourusername.github.io/my-movers-website/`.

That link is your live website — share it anywhere. Because `index.html`
sits at the root of the repo, visitors land directly on your real site,
not on a GitHub documentation/README page.

---

## How the moving parts work

- **Quote form** → on submit, JavaScript sends the details straight to
  `api.web3forms.com`, which emails them to the Gmail you registered in
  Step 1. No page reload; the visitor sees an inline confirmation message.
- **Floating Call/WhatsApp icons** (bottom-right corner) → Call opens the
  phone dialer with your number; WhatsApp opens `wa.me` with your number
  and pre-filled message, exactly like the reference site.
- **Reviews** → the 9 starter reviews are just sample text in
  `SEED_REVIEWS` (edit freely). The "Add Your Experience" form emails new
  reviews to you for approval — it does **not** auto-publish them to every
  visitor, since a static GitHub Pages site has no database to store them
  publicly. If you later want reviews to auto-appear for everyone, that
  needs a small backend (e.g. Google Sheets + Apps Script, Firebase, or
  Web3Forms' paid plan with a webhook) — happy to help set that up if you
  want to go that route.

## Troubleshooting

- **Not receiving emails?** Check Spam/Promotions in Gmail, then mark one
  as "Not spam" so future ones land in your inbox.
- **Form says "Setup needed"?** You haven't replaced
  `YOUR_WEB3FORMS_ACCESS_KEY_HERE` in `js/script.js` yet.
- **WhatsApp button doesn't open a chat?** Double-check `CONFIG.phone` has
  the country code and only digits (e.g. `91` + 10-digit number for India).
